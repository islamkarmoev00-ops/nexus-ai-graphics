package com.nexus.aigraphics;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * NEXUS AI GRAPHICS — v0.3 "invisible edge swipe".
 *
 * Architecture (why this version is different from v0.2):
 *  - v0.2 kept a permanently visible draggable "N" tab on screen. That is gone.
 *  - Instead, while the service is running, there is exactly ONE extra window: a
 *    fully transparent, narrow strip pinned to one screen edge (edgeZone). It draws
 *    nothing, so nothing is visible in the closed state.
 *  - edgeZone only reacts to an inward horizontal drag that starts inside it. Once the
 *    drag passes a threshold, the drawer (the actual panel) is opened.
 *  - While the drawer is open, a second transparent full-screen window (scrim) is added
 *    BELOW the drawer and ABOVE the game. Any touch that lands outside the drawer hits the
 *    scrim and closes the panel. This is what makes "tap outside the panel to close" possible
 *    without permanently blocking the game: the scrim only exists while the drawer is open,
 *    and is removed together with it.
 *  - The drawer itself can still be swiped back toward its edge to close, using a dedicated
 *    drag handle at the top of the panel (so it doesn't fight with the SeekBars/ScrollView
 *    inside the panel for touch events).
 *
 * Known, inherent platform limits (not bugs — see the handoff notes):
 *  1) Android's own back-gesture navigation also listens on the screen edges. We call
 *     View#setSystemGestureExclusionRects on the edge zone (API 29+) to ask the system to
 *     back off there, but this is best-effort: some OEM skins (MIUI/EMUI/etc. edge panels)
 *     run their own edge gesture on top of stock Android and are not covered by this API.
 *  2) The edge zone intercepts ALL touches that start inside its strip — including ones that
 *     were meant for a game control drawn right at that edge. We shrink the strip to the
 *     middle portion of the screen height (leaving the corners, where games usually put
 *     pause/settings buttons, free) to reduce this, but cannot eliminate it, because the
 *     window has to claim that area to detect the swipe at all.
 *  3) A regular (non-root, non-system) app cannot read another app's real FPS. There is no
 *     public Android API for that, so the Performance tab never fabricates an FPS number.
 */
public class OverlayService extends Service {
    private static final String PREFS = "nexus_overlay";
    private static final String CHANNEL_ID = "nexus_overlay_channel";
    private static final int NOTIFICATION_ID = 2042;

    private static final int BG = Color.rgb(9, 16, 30);
    private static final int CARD = Color.rgb(17, 29, 48);
    private static final int CYAN = Color.rgb(62, 211, 255);
    private static final int MUTED = Color.rgb(166, 181, 203);
    private static final int WHITE = Color.rgb(245, 249, 255);

    private static final int EDGE_ZONE_WIDTH_DP = 26;
    private static final int EDGE_ZONE_VERTICAL_MARGIN_DP = 110;
    private static final int OPEN_SWIPE_THRESHOLD_DP = 26;
    private static final int CLOSE_SWIPE_THRESHOLD_DP = 46;

    public static boolean running = false;

    private WindowManager windowManager;
    private SharedPreferences prefs;

    private View edgeZone;
    private WindowManager.LayoutParams edgeZoneParams;
    private View drawer;
    private View scrim;

    private boolean edgeRight = true;
    private boolean animationsEnabled = true;
    private int selectedTab = 0; // 0 Главная, 1 Graphics, 2 Performance, 3 Settings

    private int screenWidth;
    private int screenHeight;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        edgeRight = prefs.getBoolean("edge_right", true);
        animationsEnabled = prefs.getBoolean("animations", true);
        screenWidth = getResources().getDisplayMetrics().widthPixels;
        screenHeight = getResources().getDisplayMetrics().heightPixels;

        startOngoingNotification();
        showEdgeZone();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        screenWidth = getResources().getDisplayMetrics().widthPixels;
        screenHeight = getResources().getDisplayMetrics().heightPixels;
        if (drawer != null) closeDrawer();
        relayoutEdgeZone();
    }

    @Override
    public void onDestroy() {
        closeDrawer();
        if (edgeZone != null) {
            try { windowManager.removeView(edgeZone); } catch (IllegalArgumentException ignored) { }
            edgeZone = null;
        }
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ---------------------------------------------------------------- foreground notification

    private void startOngoingNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager != null) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "NEXUS игровая панель", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Показывает, что невидимая зона жеста активна");
            manager.createNotificationChannel(channel);
        }

        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent contentIntent = null;
        if (launchIntent != null) {
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
            contentIntent = PendingIntent.getActivity(this, 0, launchIntent, flags);
        }

        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID);
        builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("NEXUS AI GRAPHICS активен")
                .setContentText("Свайп от " + (edgeRight ? "правого" : "левого") + " края открывает панель")
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE);
        if (contentIntent != null) builder.setContentIntent(contentIntent);
        Notification notification = builder.build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    // ---------------------------------------------------------------- window helpers

    private WindowManager.LayoutParams params(int width, int height, int gravity) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags, PixelFormat.TRANSLUCENT);
        p.gravity = gravity;
        return p;
    }

    // ---------------------------------------------------------------- invisible edge gesture zone

    private void showEdgeZone() {
        if (edgeZone != null) return;
        View zone = new View(this);
        zone.setBackgroundColor(Color.TRANSPARENT);
        zone.setOnTouchListener(new EdgeSwipeListener());

        int width = dp(EDGE_ZONE_WIDTH_DP);
        int margin = dp(EDGE_ZONE_VERTICAL_MARGIN_DP);
        int height = Math.max(dp(160), screenHeight - margin * 2);
        int gravity = Gravity.TOP | (edgeRight ? Gravity.RIGHT : Gravity.LEFT);

        WindowManager.LayoutParams p = params(width, height, gravity);
        p.y = margin;

        try {
            windowManager.addView(zone, p);
        } catch (RuntimeException e) {
            // SYSTEM_ALERT_WINDOW not granted, or window addition rejected by the system.
            edgeZone = null;
            edgeZoneParams = null;
            return;
        }
        edgeZone = zone;
        edgeZoneParams = p;
        requestGestureExclusion(zone, width, height);
    }

    private void relayoutEdgeZone() {
        if (edgeZone == null || edgeZoneParams == null) return;
        int margin = dp(EDGE_ZONE_VERTICAL_MARGIN_DP);
        edgeZoneParams.height = Math.max(dp(160), screenHeight - margin * 2);
        edgeZoneParams.y = margin;
        edgeZoneParams.gravity = Gravity.TOP | (edgeRight ? Gravity.RIGHT : Gravity.LEFT);
        try { windowManager.updateViewLayout(edgeZone, edgeZoneParams); }
        catch (IllegalArgumentException ignored) { }
        requestGestureExclusion(edgeZone, edgeZoneParams.width, edgeZoneParams.height);
    }

    private void moveEdgeZoneToSelectedEdge() {
        relayoutEdgeZone();
    }

    /** Best-effort: ask the system to not treat touches in this strip as its own back gesture.
     *  Only available from API 29; on older versions the edge zone still works, it just has to
     *  compete with the system gesture for the very first pixels of the swipe. */
    private void requestGestureExclusion(final View v, final int width, final int height) {
        if (Build.VERSION.SDK_INT < 29) return;
        v.post(new Runnable() {
            @Override public void run() {
                try {
                    List<Rect> rects = new ArrayList<>();
                    rects.add(new Rect(0, 0, width, height));
                    v.setSystemGestureExclusionRects(rects);
                } catch (Exception ignored) { }
            }
        });
    }

    private class EdgeSwipeListener implements View.OnTouchListener {
        private float downX;
        private float downY;
        private boolean triggered;

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX();
                    downY = event.getRawY();
                    triggered = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (triggered) return true;
                    float dx = event.getRawX() - downX;
                    float dy = event.getRawY() - downY;
                    float inward = edgeRight ? -dx : dx;
                    if (inward > dp(OPEN_SWIPE_THRESHOLD_DP) && inward > Math.abs(dy)) {
                        triggered = true;
                        openDrawer();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    triggered = false;
                    return true;
                default:
                    return true;
            }
        }
    }

    // ---------------------------------------------------------------- drawer open / close

    private void openDrawer() {
        if (drawer != null) return;
        showScrim();

        int width = Math.min(dp(330), screenWidth - dp(18));
        int height = Math.min(dp(600), screenHeight - dp(60));
        int gravity = Gravity.TOP | (edgeRight ? Gravity.RIGHT : Gravity.LEFT);
        WindowManager.LayoutParams p = params(width, height, gravity);
        p.x = 0;
        p.y = Math.max(dp(24), (screenHeight - height) / 2);

        View panel = buildDrawer();
        if (animationsEnabled) panel.setTranslationX(edgeRight ? width : -width);

        try {
            windowManager.addView(panel, p);
        } catch (RuntimeException e) {
            hideScrim();
            return;
        }
        drawer = panel;

        if (animationsEnabled) {
            panel.animate().translationX(0).setDuration(190)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private void closeDrawer() {
        if (drawer == null) { hideScrim(); return; }
        final View old = drawer;
        drawer = null;
        hideScrim();

        Runnable remove = new Runnable() {
            @Override public void run() {
                try { windowManager.removeView(old); } catch (IllegalArgumentException ignored) { }
            }
        };
        if (animationsEnabled) {
            old.animate().translationX(edgeRight ? old.getWidth() : -old.getWidth())
                    .setDuration(150).withEndAction(remove).start();
        } else {
            remove.run();
        }
    }

    /** Rebuilds the drawer in place (same position/size) after a tab switch or a settings
     *  change, without re-running the open animation. */
    private void replaceDrawerContent() {
        if (drawer == null) return;
        View old = drawer;
        int width = old.getWidth() > 0 ? old.getWidth() : Math.min(dp(330), screenWidth - dp(18));
        int height = old.getHeight() > 0 ? old.getHeight() : Math.min(dp(600), screenHeight - dp(60));
        try { windowManager.removeView(old); } catch (IllegalArgumentException ignored) { }

        View panel = buildDrawer();
        WindowManager.LayoutParams p = params(width, height, Gravity.TOP | (edgeRight ? Gravity.RIGHT : Gravity.LEFT));
        p.x = 0;
        p.y = Math.max(dp(24), (screenHeight - height) / 2);
        try {
            windowManager.addView(panel, p);
            drawer = panel;
        } catch (RuntimeException e) {
            drawer = null;
            hideScrim();
        }
    }

    /** Full-screen, fully transparent window added below the drawer while it's open. Any touch
     *  landing outside the drawer's own bounds hits this window instead of the game, and closes
     *  the panel. It is added/removed together with the drawer, so the game is never blocked
     *  while the panel is closed. */
    private void showScrim() {
        if (scrim != null) return;
        View s = new View(this);
        s.setBackgroundColor(Color.TRANSPARENT);
        s.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN) closeDrawer();
                return true;
            }
        });
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        try {
            windowManager.addView(s, p);
            scrim = s;
        } catch (RuntimeException ignored) {
            scrim = null;
        }
    }

    private void hideScrim() {
        if (scrim == null) return;
        try { windowManager.removeView(scrim); } catch (IllegalArgumentException ignored) { }
        scrim = null;
    }

    /** Drag handle at the top of the drawer: swiping it toward the docked edge closes the panel.
     *  Kept as its own view (not the whole drawer) so it never fights the SeekBars/ScrollView
     *  used elsewhere in the panel for touch events. */
    private void attachCloseGrip(View grip, final View panel) {
        grip.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float startTranslation;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        startTranslation = panel.getTranslationX();
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = event.getRawX() - downX;
                        float outward = edgeRight ? Math.max(0, dx) : Math.min(0, dx);
                        panel.setTranslationX(startTranslation + outward);
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        float moved = Math.abs(panel.getTranslationX() - startTranslation);
                        if (moved > dp(CLOSE_SWIPE_THRESHOLD_DP)) {
                            closeDrawer();
                        } else {
                            panel.animate().translationX(0).setDuration(130).start();
                        }
                        return true;
                    }
                    default:
                        return true;
                }
            }
        });
    }

    // ---------------------------------------------------------------- drawer content

    private View buildDrawer() {
        LinearLayout root = vertical();
        root.setPadding(dp(13), dp(4), dp(13), dp(10));
        root.setBackground(shape(BG, Color.rgb(39, 119, 153), 20));

        LinearLayout gripRow = vertical();
        gripRow.setGravity(Gravity.CENTER_HORIZONTAL);
        gripRow.setPadding(0, dp(8), 0, dp(6));
        View gripBar = new View(this);
        gripBar.setBackground(shape(Color.rgb(54, 94, 116), 0, 3));
        gripRow.addView(gripBar, new LinearLayout.LayoutParams(dp(34), dp(4)));
        root.addView(gripRow, new LinearLayout.LayoutParams(-1, dp(26)));
        attachCloseGrip(gripRow, root);

        LinearLayout header = horizontal();
        LinearLayout titleBox = vertical();
        titleBox.addView(label("NEXUS  /  GAME PANEL", 15, CYAN, true));
        titleBox.addView(label("БЫСТРЫЙ ДОСТУП В ИГРЕ", 9, MUTED, false));
        header.addView(titleBox, new LinearLayout.LayoutParams(0, dp(43), 1));
        TextView close = label("×", 27, WHITE, false);
        close.setGravity(Gravity.CENTER);
        close.setBackground(shape(CARD, Color.rgb(43, 69, 91), 12));
        header.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38)));
        close.setOnClickListener(v -> closeDrawer());
        root.addView(header);

        LinearLayout tabs = horizontal();
        tabs.setPadding(0, dp(10), 0, dp(9));
        String[] names = {"Главная", "Graphics", "Performance", "Settings"};
        for (int i = 0; i < names.length; i++) {
            final int index = i;
            TextView tab = label(names[i], 10, selectedTab == i ? WHITE : MUTED, selectedTab == i);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(dp(2), dp(9), dp(2), dp(9));
            tab.setBackground(shape(selectedTab == i ? Color.rgb(16, 75, 103) : CARD,
                    selectedTab == i ? CYAN : Color.TRANSPARENT, 10));
            LinearLayout.LayoutParams tabLp = new LinearLayout.LayoutParams(0, dp(36), 1);
            if (i > 0) tabLp.leftMargin = dp(4);
            tabs.addView(tab, tabLp);
            tab.setOnClickListener(v -> { selectedTab = index; replaceDrawerContent(); });
        }
        root.addView(tabs);

        View separator = new View(this);
        separator.setBackgroundColor(Color.rgb(39, 55, 77));
        root.addView(separator, new LinearLayout.LayoutParams(-1, dp(1)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = vertical();
        content.setPadding(0, dp(10), 0, dp(8));
        addTabContent(content);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        return root;
    }

    private void addTabContent(LinearLayout content) {
        switch (selectedTab) {
            case 0: addHome(content); break;
            case 1: addGraphics(content); break;
            case 2: addPerformance(content); break;
            default: addSettingsTab(content); break;
        }
    }

    private void addHome(LinearLayout content) {
        LinearLayout statusCard = card();
        statusCard.addView(label("●  СЛУЖБА АКТИВНА", 12, CYAN, true));
        TextView info = label("Невидимая зона жеста у " + (edgeRight ? "правого" : "левого")
                + " края: свайп внутрь экрана открывает панель. Нажмите ×, свайпните полосу "
                + "наверху панели к краю или коснитесь вне панели, чтобы закрыть.", 11, WHITE, false);
        info.setPadding(0, dp(7), 0, 0);
        statusCard.addView(info);
        content.addView(statusCard, cardParams());

        addInfoCard(content, "ГРАФИЧЕСКИЙ ПРОФИЛЬ", profileSummary(),
                "Резкость/контраст/насыщенность сохраняются как профиль. Обработка кадров игры не выполняется — см. вкладку Graphics.");
        addInfoCard(content, "ДВИЖОК ОБРАБОТКИ", "Пока не подключён",
                "Эта версия не меняет кадры, текстуры или FPS самой игры.");

        TextView go = actionText("Открыть Settings  →");
        content.addView(go, new LinearLayout.LayoutParams(-1, dp(42)));
        go.setOnClickListener(v -> { selectedTab = 3; replaceDrawerContent(); });
    }

    private String profileSummary() {
        return "Резкость " + prefs.getInt("sharpness", 35) + "% · Контраст " + prefs.getInt("contrast", 50)
                + "% · Насыщ. " + prefs.getInt("saturation", 50) + "%";
    }

    private void addGraphics(LinearLayout content) {
        content.addView(label("GRAPHICS", 12, CYAN, true), new LinearLayout.LayoutParams(-1, dp(28)));
        TextView notice = label("Значения сохраняются как профиль, но пока не применяются к изображению игры: "
                + "конвейер захвата/обработки кадров ещё не подключён.", 10, MUTED, false);
        notice.setPadding(0, 0, 0, dp(9));
        content.addView(notice);

        addSavedSlider(content, "Резкость (Sharpness)", "sharpness", 35);
        addSavedSlider(content, "Контраст (Contrast)", "contrast", 50);
        addSavedSlider(content, "Насыщенность (Saturation)", "saturation", 50);

        TextView reset = actionText("Сбросить профиль");
        content.addView(reset, new LinearLayout.LayoutParams(-1, dp(40)));
        reset.setOnClickListener(v -> {
            prefs.edit().putInt("sharpness", 35).putInt("contrast", 50).putInt("saturation", 50).apply();
            selectedTab = 1;
            replaceDrawerContent();
        });
    }

    private void addSavedSlider(LinearLayout parent, String title, String key, int fallback) {
        LinearLayout item = card();
        LinearLayout row = horizontal();
        row.addView(label(title, 12, WHITE, true), new LinearLayout.LayoutParams(0, dp(26), 1));
        TextView value = label(prefs.getInt(key, fallback) + "%", 11, CYAN, true);
        value.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        row.addView(value);
        item.addView(row);

        SeekBar seek = new SeekBar(this);
        seek.setMax(100);
        seek.setProgress(prefs.getInt(key, fallback));
        seek.setProgressTintList(ColorStateList.valueOf(CYAN));
        seek.setThumbTintList(ColorStateList.valueOf(WHITE));
        seek.setProgressBackgroundTintList(ColorStateList.valueOf(Color.rgb(48, 65, 86)));
        item.addView(seek, new LinearLayout.LayoutParams(-1, dp(35)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                value.setText(progress + "%");
                if (fromUser) prefs.edit().putInt(key, progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        parent.addView(item, cardParams());
    }

    private void addPerformance(LinearLayout content) {
        content.addView(label("PERFORMANCE", 12, CYAN, true), new LinearLayout.LayoutParams(-1, dp(28)));

        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (am != null) {
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long totalMb = mi.totalMem / (1024 * 1024);
            long availMb = mi.availMem / (1024 * 1024);
            int usedPercent = totalMb > 0 ? (int) (100 - (availMb * 100 / totalMb)) : 0;
            addInfoCard(content, "ПАМЯТЬ УСТРОЙСТВА", usedPercent + "% занято",
                    "Свободно " + availMb + " МБ из " + totalMb + " МБ. Это общесистемные данные ОС, не показатель конкретной игры.");
        } else {
            addInfoCard(content, "ПАМЯТЬ УСТРОЙСТВА", "Недоступно", "Системная служба памяти не вернула данные.");
        }

        int cores = Runtime.getRuntime().availableProcessors();
        addInfoCard(content, "ПРОЦЕССОР", cores + " логических ядер",
                "Число ядер, видимых приложению. Текущую загрузку по ядрам и частоту Android не отдаёт сторонним приложениям без root.");

        addInfoCard(content, "FPS ИГРЫ", "Недоступно",
                "Обычное приложение-оверлей не может читать кадровую частоту чужого процесса без root или системных прав — "
                        + "мы намеренно не показываем выдуманное число. Для реального FPS используйте Developer options → "
                        + "Profile GPU Rendering или инструменты производителя GPU.");
    }

    private void addSettingsTab(LinearLayout content) {
        content.addView(label("ПОЛОЖЕНИЕ И ПОВЕДЕНИЕ", 12, CYAN, true), new LinearLayout.LayoutParams(-1, dp(30)));

        addInfoCard(content, "ОТКРЫТИЕ ПАНЕЛИ", "Свайп от края внутрь экрана",
                "Проведите пальцем от " + (edgeRight ? "правого" : "левого") + " края внутрь. Зона обнаружения невидима в закрытом состоянии.");

        TextView side = actionText(edgeRight ? "Перенести на левый край" : "Перенести на правый край");
        content.addView(side, new LinearLayout.LayoutParams(-1, dp(44)));
        side.setOnClickListener(v -> {
            edgeRight = !edgeRight;
            prefs.edit().putBoolean("edge_right", edgeRight).apply();
            moveEdgeZoneToSelectedEdge();
            closeDrawer();
        });

        TextView anim = actionText(animationsEnabled ? "Выключить анимацию" : "Включить анимацию");
        content.addView(anim, new LinearLayout.LayoutParams(-1, dp(44)));
        anim.setOnClickListener(v -> {
            animationsEnabled = !animationsEnabled;
            prefs.edit().putBoolean("animations", animationsEnabled).apply();
            selectedTab = 3;
            replaceDrawerContent();
        });

        TextView stop = actionText("Остановить службу");
        stop.setTextColor(Color.rgb(255, 143, 143));
        content.addView(stop, new LinearLayout.LayoutParams(-1, dp(44)));
        stop.setOnClickListener(v -> stopSelf());

        TextView reset = actionText("Сбросить все настройки");
        content.addView(reset, new LinearLayout.LayoutParams(-1, dp(44)));
        reset.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            edgeRight = true;
            animationsEnabled = true;
            moveEdgeZoneToSelectedEdge();
            selectedTab = 3;
            replaceDrawerContent();
        });

        TextView note = label("Подсказка: первое касание за пределами панели закрывает её, а не передаётся игре — "
                + "это и позволяет закрывать панель нажатием снаружи.", 10, MUTED, false);
        note.setPadding(dp(2), dp(10), dp(2), 0);
        content.addView(note);
    }

    // ---------------------------------------------------------------- small view builders

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout card() {
        LinearLayout c = vertical();
        c.setPadding(dp(11), dp(10), dp(11), dp(9));
        c.setBackground(shape(CARD, Color.rgb(39, 60, 82), 13));
        return c;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(9);
        return p;
    }

    private void addInfoCard(LinearLayout parent, String eyebrow, String title, String detail) {
        LinearLayout c = card();
        c.addView(label(eyebrow, 9, MUTED, true));
        TextView heading = label(title, 14, WHITE, true);
        heading.setPadding(0, dp(3), 0, dp(2));
        c.addView(heading);
        c.addView(label(detail, 10, MUTED, false));
        parent.addView(c, cardParams());
    }

    private TextView actionText(String text) {
        TextView t = label(text, 11, CYAN, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(shape(Color.rgb(13, 55, 79), Color.rgb(36, 126, 159), 11));
        t.setPadding(dp(7), dp(5), dp(7), dp(5));
        return t;
    }
}

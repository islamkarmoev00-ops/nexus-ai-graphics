package com.nexus.aigraphics;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(8, 14, 26);
    private static final int CARD = Color.rgb(17, 29, 48);
    private static final int CYAN = Color.rgb(62, 211, 255);
    private static final int WHITE = Color.rgb(245, 249, 255);
    private static final int MUTED = Color.rgb(170, 185, 207);
    private TextView status;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(24));
        root.setBackgroundColor(BG);

        TextView eyebrow = text("ANDROID GAMING TOOLKIT  •  v0.3", 11, CYAN, true);
        eyebrow.setGravity(Gravity.CENTER);
        root.addView(eyebrow, new LinearLayout.LayoutParams(-1, dp(28)));

        TextView title = text("NEXUS AI\nGRAPHICS", 31, WHITE, true);
        title.setGravity(Gravity.CENTER);
        title.setLineSpacing(0, 0.95f);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(104)));

        TextView description = text("Скрытая игровая шторка. Открывается горизонтальным свайпом от края экрана.", 14, MUTED, false);
        description.setGravity(Gravity.CENTER);
        description.setPadding(dp(10), 0, dp(10), dp(16));
        root.addView(description);

        LinearLayout statusCard = card();
        TextView statusTitle = text("СОСТОЯНИЕ", 10, CYAN, true);
        statusCard.addView(statusTitle);
        status = text("Проверяем разрешения…", 14, WHITE, true);
        status.setPadding(0, dp(6), 0, 0);
        statusCard.addView(status);
        root.addView(statusCard, cardParams());

        Button permission = button("Разрешение «Поверх других приложений»");
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                updateStatus();
            }
        });
        root.addView(permission, buttonParams());

        Button start = button("Запустить скрытую игровую шторку");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                status.setText("Сначала разреши отображение поверх других приложений.");
                return;
            }
            Intent service = new Intent(this, OverlayService.class);
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundServiceIfNeeded(service);
            else startService(service);
            status.setText("Скрытая шторка активна. Проведи пальцем от правой стороны экрана внутрь.");
        });
        root.addView(start, buttonParams());

        Button stop = button("Остановить скрытую шторку");
        stop.setTextColor(Color.rgb(255, 164, 164));
        stop.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(67, 35, 48)));
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            updateStatus();
        });
        root.addView(stop, buttonParams());

        LinearLayout noteCard = card();
        noteCard.addView(text("КАК ОТКРЫТЬ ШТОРКУ", 10, CYAN, true));
        noteCard.addView(text("1. Запусти скрытую шторку.\n2. Перейди в игру.\n3. Проведи пальцем горизонтально от правой стороны чуть внутрь экрана.\n4. Чтобы закрыть, нажми ×. В настройках панели можно перенести жест на левый край.",
                12, WHITE, false));
        root.addView(noteCard, cardParams());

        LinearLayout honestCard = card();
        honestCard.addView(text("ВАЖНО О ГРАФИКЕ", 10, CYAN, true));
        honestCard.addView(text("Профиль резкости, контраста и насыщенности пока только сохраняет значения. Он ещё не обрабатывает изображение игры и не меняет текстуры, тени или FPS. Для этого потребуется отдельный конвейер захвата и обработки кадров; некоторые игры не разрешают захват.",
                11, MUTED, false));
        root.addView(honestCard, cardParams());

        scroll.addView(root);
        setContentView(scroll);
        updateStatus();
    }

    private void startForegroundServiceIfNeeded(Intent service) {
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service);
        else startService(service);
    }

    private void updateStatus() {
        if (status == null) return;
        boolean allowed = Settings.canDrawOverlays(this);
        String permission = allowed ? "Разрешение оверлея выдано" : "Нет разрешения на оверлей";
        String state = OverlayService.running ? "Скрытая игровая шторка активна" : "Скрытая игровая шторка остановлена";
        status.setText(permission + "\n" + state);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(15));
        bg.setStroke(dp(1), Color.rgb(40, 61, 83));
        c.setBackground(bg);
        return c;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(12);
        return p;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinHeight(dp(54));
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(17, 76, 105)));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56));
        p.bottomMargin = dp(9);
        return p;
    }
}

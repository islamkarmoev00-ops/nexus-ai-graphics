package com.nexus.aigraphics;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** Compact edge-docked game overlay. Image controls are saved as a profile only;
 *  this prototype does not yet process or replace the game's rendered frames. */
public class OverlayService extends Service {
    private static final String PREFS = "nexus_overlay";
    private static final String CHANNEL_ID = "nexus_overlay_channel";
    private static final int NOTIFICATION_ID = 2042;
    private static final int BG = Color.rgb(9, 16, 30);
    private static final int CARD = Color.rgb(17, 29, 48);
    private static final int CYAN = Color.rgb(62, 211, 255);
    private static final int MUTED = Color.rgb(166, 181, 203);
    private static final int WHITE = Color.rgb(245, 249, 255);

    public static boolean running = false;

    private WindowManager windowManager;
    private View edgeTrigger;
    private View drawer;
    private WindowManager.LayoutParams triggerParams;
    private boolean edgeRight = true;
    private int selectedTab = 0;
    private SharedPreferences prefs;
    private int screenHeight;
    private int screenWidth;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        startOngoingNotification();
        edgeRight = prefs.getBoolean("edge_right", true);
        screenWidth = getResources().getDisplayMetrics().widthPixels;
        screenHeight = getResources().getDisplayMetrics().heightPixels;
        selectedTab = prefs.getInt("selected_tab", 0);
        showEdgeTrigger();
    }


    private void startOngoingNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "NEXUS игровая панель", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Показывает, что боковая игровая панель активна");
            manager.createNotificationChannel(channel);
        }

        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent contentIntent = null;
        if (launchIntent != null) {
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
            contentIntent = PendingIntent.getActivity(this, 0, launchIntent, flags);
        }

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("NEXUS AI GRAPHICS активен")
                .setContentText("Проведите от выбранного края экрана внутрь, чтобы открыть панель")
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE);
        if (contentIntent != null) builder.setContentIntent(contentIntent);
        Notification notification = builder.build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private WindowManager.LayoutParams params(int width, int height, int gravity) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                width, height, overlayType(), flags, PixelFormat.TRANSLUCENT);
        p.gravity = gravity;
        return p;
    }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (stroke > 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    /**
     * Полностью прозрачная сенсорная зона. Никакой видимой вкладки N нет.
     * Зона немного отодвинута от физического края, чтобы уменьшить конфликт
     * с системным жестом «Назад» на Android.
     */
    private void showEdgeTrigger() {
        if (edgeTrigger != null) return;

        View trigger = new View(this);
        trigger.setBackgroundColor(Color.TRANSPARENT);
        trigger.setContentDescription("NEXUS: проведите от края экрана внутрь для открытия панели");
        trigger.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float downY;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        downY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        boolean inwardSwipe = edgeRight
                                ? dx < -dp(48)
                                : dx > dp(48);
                        if (inwardSwipe && Math.abs(dx) > Math.abs(dy) * 1.15f) {
                            openDrawer();
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                    default:
                        return true;
                }
            }
        });

        int gravity = Gravity.CENTER_VERTICAL | (edgeRight ? Gravity.RIGHT : Gravity.LEFT);
        triggerParams = params(dp(28), dp(230), gravity);
        // Располагаем зону чуть дальше системной области «Назад» Android.
        triggerParams.x = dp(28);
        edgeTrigger = trigger;
        try {
            windowManager.addView(edgeTrigger, triggerParams);
        } catch (RuntimeException error) {
            edgeTrigger = null;
            triggerParams = null;
        }
    }

    private void removeEdgeTrigger() {
        if (edgeTrigger != null) {
            try { windowManager.removeView(edgeTrigger); }
            catch (IllegalArgumentException ignored) { }
            edgeTrigger = null;
            triggerParams = null;
        }
    }

    private void openDrawer() {
        if (drawer != null) {
            closeDrawer();
            return;
        }
        drawer = buildDrawer();
        int width = Math.min(dp(326), screenWidth - dp(18));
        int height = Math.min(dp(590), screenHeight - dp(70));
        int gravity = Gravity.TOP | (edgeRight ? Gravity.RIGHT : Gravity.LEFT);
        WindowManager.LayoutParams p = params(width, height, gravity);
        p.x = 0;
        p.y = Math.max(dp(24), (screenHeight - height) / 2);
        try {
            drawer.setTranslationX(edgeRight ? width : -width);
            drawer.setAlpha(0.96f);
            windowManager.addView(drawer, p);
            View added = drawer;
            added.animate().translationX(0).setDuration(190)
                    .setInterpolator(new DecelerateInterpolator()).start();
        } catch (RuntimeException e) {
            drawer = null;
        }
    }

    private void closeDrawer() {
        if (drawer == null) return;
        final View old = drawer;
        drawer = null;
        old.animate().translationX(edgeRight ? old.getWidth() : -old.getWidth())
                .alpha(0.75f).setDuration(150)
                .withEndAction(() -> {
                    try { windowManager.removeView(old); }
                    catch (IllegalArgumentException ignored) { }
                }).start();
    }

    private View buildDrawer() {
        LinearLayout root = vertical();
        root.setPadding(dp(13), dp(12), dp(13), dp(10));
        root.setBackground(shape(BG, Color.rgb(39, 119, 153), 20));

        LinearLayout header = horizontal();
        LinearLayout titleBox = vertical();
        TextView title = label("NEXUS  /  GAME PANEL", 15, CYAN, true);
        titleBox.addView(title);
        TextView subtitle = label("БЫСТРЫЙ ДОСТУП В ИГРЕ", 9, MUTED, false);
        titleBox.addView(subtitle);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, dp(43), 1));
        TextView close = label("×", 27, WHITE, false);
        close.setGravity(Gravity.CENTER);
        close.setBackground(shape(CARD, Color.rgb(43, 69, 91), 12));
        header.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38)));
        close.setOnClickListener(v -> closeDrawer());
        root.addView(header);

        TextView swipeGrip = label("━━━━━━", 11, MUTED, true);
        swipeGrip.setGravity(Gravity.CENTER);
        swipeGrip.setContentDescription("Проведите от панели наружу, чтобы закрыть её");
        root.addView(swipeGrip, new LinearLayout.LayoutParams(-1, dp(22)));
        swipeGrip.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            @Override public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = event.getRawX();
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    float dx = event.getRawX() - downX;
                    boolean outward = edgeRight ? dx > dp(65) : dx < -dp(65);
                    if (outward) closeDrawer();
                    return true;
                }
                return true;
            }
        });

        LinearLayout tabs = horizontal();
        tabs.setPadding(0, dp(10), 0, dp(9));
        String[] names = {"Обзор", "Изображение", "Панель"};
        for (int i = 0; i < names.length; i++) {
            final int index = i;
            TextView tab = label(names[i], 11, selectedTab == i ? WHITE : MUTED, selectedTab == i);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(dp(4), dp(9), dp(4), dp(9));
            tab.setBackground(shape(selectedTab == i ? Color.rgb(16, 75, 103) : CARD,
                    selectedTab == i ? CYAN : Color.TRANSPARENT, 10));
            LinearLayout.LayoutParams tabLp = new LinearLayout.LayoutParams(0, dp(36), 1);
            if (i > 0) tabLp.leftMargin = dp(5);
            tabs.addView(tab, tabLp);
            tab.setOnClickListener(v -> {
                selectedTab = index;
                prefs.edit().putInt("selected_tab", selectedTab).apply();
                replaceDrawerContent();
            });
        }
        root.addView(tabs);

        View separator = new View(this);
        separator.setBackgroundColor(Color.rgb(39, 55, 77));
        root.addView(separator, new LinearLayout.LayoutParams(-1, dp(1)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = vertical();
        content.setPadding(0, dp(10), 0, dp(8));
        addTabContent(content);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = label("× или свайп по полоске наружу — закрыть", 9, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(8), 0, 0);
        root.addView(footer, new LinearLayout.LayoutParams(-1, dp(24)));
        return root;
    }

    private void replaceDrawerContent() {
        if (drawer == null) return;
        // Rebuild in place so the panel dimensions and edge position remain unchanged.
        View old = drawer;
        int width = old.getWidth();
        int height = old.getHeight();
        try { windowManager.removeView(old); } catch (IllegalArgumentException ignored) { }
        drawer = buildDrawer();
        WindowManager.LayoutParams p = params(width > 0 ? width : Math.min(dp(326), screenWidth - dp(18)),
                height > 0 ? height : Math.min(dp(590), screenHeight - dp(70)),
                Gravity.TOP | (edgeRight ? Gravity.RIGHT : Gravity.LEFT));
        p.x = 0;
        p.y = Math.max(dp(24), (screenHeight - p.height) / 2);
        windowManager.addView(drawer, p);
    }

    private void addTabContent(LinearLayout content) {
        if (selectedTab == 0) addOverview(content);
        else if (selectedTab == 1) addImageProfile(content);
        else addPanelSettings(content);
    }

    private void addOverview(LinearLayout content) {
        LinearLayout statusCard = card();
        TextView ready = label("●  БОКОВАЯ ПАНЕЛЬ АКТИВНА", 12, CYAN, true);
        statusCard.addView(ready);
        TextView info = label("Панель открывается невидимым горизонтальным свайпом от выбранного края экрана. Закройте её кнопкой ×.",
                11, WHITE, false);
        info.setPadding(0, dp(7), 0, 0);
        statusCard.addView(info);
        content.addView(statusCard, cardParams());

        addInfoCard(content, "ПРОФИЛЬ", "Сбалансированный", "Сохранённый набор предпочтений для будущего графического конвейера.");
        addInfoCard(content, "ГРАФИЧЕСКИЙ ДВИЖОК", "Пока не подключён", "Эта версия не меняет кадры, текстуры или настройки самой игры.");
        TextView go = actionText("Настроить профиль изображения  →");
        content.addView(go, new LinearLayout.LayoutParams(-1, dp(42)));
        go.setOnClickListener(v -> {
            selectedTab = 1;
            prefs.edit().putInt("selected_tab", selectedTab).apply();
            replaceDrawerContent();
        });
    }

    private void addImageProfile(LinearLayout content) {
        TextView intro = label("ПРОФИЛЬ ИЗОБРАЖЕНИЯ", 12, CYAN, true);
        content.addView(intro, new LinearLayout.LayoutParams(-1, dp(28)));
        TextView notice = label("Здесь можно сохранить желаемые значения. Они пока не применяются к игровому изображению: обработчик кадров ещё не подключён.",
                10, MUTED, false);
        notice.setPadding(0, 0, 0, dp(9));
        content.addView(notice);
        addSavedSlider(content, "Резкость", "sharpness", 35);
        addSavedSlider(content, "Контраст", "contrast", 50);
        addSavedSlider(content, "Насыщенность", "saturation", 50);
        TextView reset = actionText("Сбросить профиль");
        content.addView(reset, new LinearLayout.LayoutParams(-1, dp(40)));
        reset.setOnClickListener(v -> {
            prefs.edit().putInt("sharpness", 35).putInt("contrast", 50)
                    .putInt("saturation", 50).apply();
            selectedTab = 1;
            prefs.edit().putInt("selected_tab", selectedTab).apply();
            replaceDrawerContent();
        });
    }

    private void addSavedSlider(LinearLayout parent, String title, String key, int fallback) {
        LinearLayout item = card();
        LinearLayout row = horizontal();
        TextView name = label(title, 12, WHITE, true);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(26), 1));
        TextView value = label(String.valueOf(prefs.getInt(key, fallback)) + "%", 11, CYAN, true);
        value.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        row.addView(value);
        item.addView(row);
        SeekBar seek = new SeekBar(this);
        seek.setMax(100);
        seek.setProgress(prefs.getInt(key, fallback));
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(WHITE));
        seek.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(48, 65, 86)));
        item.addView(seek, new LinearLayout.LayoutParams(-1, dp(35)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                value.setText(progress + "%");
                if (fromUser) prefs.edit().putInt(key, progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        parent.addView(item, cardParams());
    }

    private void addPanelSettings(LinearLayout content) {
        TextView intro = label("ЖЕСТ И ПОВЕДЕНИЕ ПАНЕЛИ", 12, CYAN, true);
        content.addView(intro, new LinearLayout.LayoutParams(-1, dp(30)));

        addInfoCard(content, "ОТКРЫТИЕ", edgeRight ? "Правый край экрана" : "Левый край экрана",
                "Проведите пальцем от прозрачной зоны у края внутрь экрана. Видимой кнопки или вкладки нет.");

        TextView side = actionText(edgeRight ? "Переключить свайп на левый край" : "Переключить свайп на правый край");
        content.addView(side, new LinearLayout.LayoutParams(-1, dp(44)));
        side.setOnClickListener(v -> {
            edgeRight = !edgeRight;
            prefs.edit().putBoolean("edge_right", edgeRight).apply();
            moveTriggerToSelectedEdge();
            replaceDrawerContent();
        });

        TextView reset = actionText("Сбросить профиль изображения");
        content.addView(reset, new LinearLayout.LayoutParams(-1, dp(44)));
        reset.setOnClickListener(v -> {
            prefs.edit().putInt("sharpness", 35).putInt("contrast", 50)
                    .putInt("saturation", 50).apply();
            selectedTab = 1;
            prefs.edit().putInt("selected_tab", selectedTab).apply();
            replaceDrawerContent();
        });

        TextView stop = actionText("Остановить NEXUS");
        stop.setTextColor(Color.rgb(255, 143, 143));
        content.addView(stop, new LinearLayout.LayoutParams(-1, dp(44)));
        stop.setOnClickListener(v -> stopSelf());

        TextView note = label("Важно: системный жест «Назад» Android может иметь приоритет у самого края. Поэтому невидимая зона расположена чуть внутри экрана.",
                10, MUTED, false);
        note.setPadding(dp(2), dp(10), dp(2), 0);
        content.addView(note);
    }

    private LinearLayout card() {
        LinearLayout c = vertical();
        c.setPadding(dp(11), dp(10), dp(11), dp(9));
        c.setBackground(shape(CARD, Color.rgb(39, 60, 82), 13));
        return c;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(9);
        return p;
    }

    private void addInfoCard(LinearLayout parent, String eyebrow, String title, String detail) {
        LinearLayout c = card();
        c.addView(label(eyebrow, 9, MUTED, true));
        TextView heading = label(title, 14, WHITE, true);
        heading.setPadding(0, dp(3), 0, dp(2));
        c.addView(heading);
        c.addView(label(detail, 10, MUTED, false));
        parent.addView(c, cardParams());
    }

    private TextView actionText(String text) {
        TextView t = label(text, 11, CYAN, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(shape(Color.rgb(13, 55, 79), Color.rgb(36, 126, 159), 11));
        t.setPadding(dp(7), dp(5), dp(7), dp(5));
        return t;
    }

    private void moveTriggerToSelectedEdge() {
        removeEdgeTrigger();
        showEdgeTrigger();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        screenWidth = getResources().getDisplayMetrics().widthPixels;
        screenHeight = getResources().getDisplayMetrics().heightPixels;
        removeEdgeTrigger();
        showEdgeTrigger();
        if (drawer != null) closeDrawer();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (drawer != null) {
            try { windowManager.removeView(drawer); } catch (IllegalArgumentException ignored) { }
            drawer = null;
        }
        removeEdgeTrigger();
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}

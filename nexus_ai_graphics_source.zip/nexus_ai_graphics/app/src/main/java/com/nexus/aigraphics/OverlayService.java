package com.nexus.aigraphics;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm; private View bubble; private View panel;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onCreate() { super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); showBubble(); }
    private WindowManager.LayoutParams lp(int w,int h,int gravity) {
        int type = android.os.Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(w,h,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
    }
    private GradientDrawable bg(int color,int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1),Color.rgb(57,213,255)); return d; }
    private TextView text(String s,int size,int color) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); return t; }
    private void showBubble() {
        if (bubble!=null) return;
        TextView b=text("N",18,Color.WHITE); b.setBackground(bg(Color.rgb(10,55,82),28)); b.setOnClickListener(v->{ if(panel==null) showPanel(); else hidePanel(); }); bubble=b;
        WindowManager.LayoutParams p=lp(dp(56),dp(56),Gravity.TOP|Gravity.END); p.x=dp(14); p.y=dp(180); wm.addView(bubble,p);
    }
    private void showPanel() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(12),dp(14),dp(12)); box.setBackground(bg(Color.rgb(8,16,31),18));
        TextView head=text("NEXUS GRAPHICS",17,Color.rgb(57,213,255)); box.addView(head,new LinearLayout.LayoutParams(-1,dp(42)));
        String[] rows={"Резкость — скоро","Сглаживание — скоро","AI Super Resolution — скоро","Профиль производительности — скоро"};
        for(String row:rows){ TextView t=text(row,13,Color.WHITE); box.addView(t,new LinearLayout.LayoutParams(-1,dp(42))); }
        TextView close=text("Свернуть",13,Color.rgb(57,213,255)); close.setOnClickListener(v->hidePanel()); box.addView(close,new LinearLayout.LayoutParams(-1,dp(38)));
        panel=box; WindowManager.LayoutParams p=lp(dp(280),dp(260),Gravity.TOP|Gravity.END); p.x=dp(12); p.y=dp(245); wm.addView(panel,p);
    }
    private void hidePanel(){ if(panel!=null){wm.removeView(panel);panel=null;} }
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){ if(panel!=null)wm.removeView(panel); if(bubble!=null)wm.removeView(bubble); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}

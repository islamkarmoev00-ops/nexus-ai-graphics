package com.nexus.aigraphics;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(34), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(8,13,24));

        TextView title = new TextView(this);
        title.setText("NEXUS AI GRAPHICS"); title.setTextColor(Color.WHITE); title.setTextSize(25); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(64)));
        TextView sub = new TextView(this);
        sub.setText("ANDROID GRAPHICS EXPERIMENT • v0.1"); sub.setTextColor(Color.rgb(57,213,255)); sub.setTextSize(11); sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1, dp(30)));

        status = new TextView(this);
        status.setText("Статус: оверлей ещё не включён"); status.setTextColor(Color.LTGRAY); status.setTextSize(15);
        status.setPadding(0, dp(24), 0, dp(20)); root.addView(status);

        Button grant = button("1. Разрешить отображение поверх игр");
        grant.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else status.setText("Разрешение оверлея уже выдано.");
        }); root.addView(grant, params());

        Button launch = button("2. Запустить плавающую панель");
        launch.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) { status.setText("Сначала выдай разрешение на отображение поверх других приложений."); return; }
            startService(new Intent(this, OverlayService.class));
            status.setText("Плавающая кнопка запущена. Открой игру и нажми на неё.");
        }); root.addView(launch, params());

        TextView note = new TextView(this);
        note.setText("ВАЖНО\nЭто ранний прототип: плавающая панель и разрешения. Обработка кадров игры, AI Super Resolution и изменение игровых текстур ещё не реализованы. Android не гарантирует захват изображения каждой игры.");
        note.setTextColor(Color.rgb(180,190,210)); note.setTextSize(13); note.setPadding(0, dp(26), 0, 0);
        root.addView(note);
        setContentView(root);
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(20,65,91))); return b;
    }
    private LinearLayout.LayoutParams params() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58)); p.bottomMargin = dp(12); return p; }
}

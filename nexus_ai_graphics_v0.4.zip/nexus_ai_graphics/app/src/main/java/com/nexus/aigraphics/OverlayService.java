package com.nexus.aigraphics;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;

import java.util.Collections;
import java.util.Set;

/**
 * NEXUS AI GRAPHICS — v0.4 "per-game auto filter".
 *
 * This version has no side panel / drawer at all. Instead, while the service is running:
 *  1. Every POLL_INTERVAL_MS it checks (via UsageStatsManager) which app was most recently
 *     brought to the foreground.
 *  2. If that app is in the user's target list (configured in MainActivity), it shows a
 *     single transparent overlay window (FilterOverlayView) on top of it, using that app's
 *     saved tint/dim/vignette profile.
 *  3. If the foreground app leaves the target list (home screen, a different app, etc.),
 *     the overlay is removed.
 *
 * What FilterOverlayView can and cannot do — read this before changing expectations:
 *  - It is a translucent window painted ON TOP of the game. It can genuinely dim the screen,
 *    tint it warmer/cooler, and draw a vignette, because those are real pixels composited
 *    over whatever is underneath.
 *  - It CANNOT sharpen the game's image or remove real blur, because it has no access to the
 *    game's actual pixels — only addition on top is possible, not reading/transforming what's
 *    below. No permission changes this; it is a platform sandboxing boundary, not a missing
 *    setting. See README_RU.md for the full explanation.
 *
 * Foreground detection limits (also platform, not bugs):
 *  - PACKAGE_USAGE_STATS-gated APIs are polled, not pushed, so detection can lag by up to
 *    POLL_INTERVAL_MS, and a very quick app switch inside that window can be missed.
 *  - If the user has not granted "Usage access" in system settings, queryEvents() silently
 *    returns nothing — the service keeps running, it just never detects a foreground app.
 */
public class OverlayService extends Service {
    private static final String PREFS = "nexus_overlay";
    private static final String CHANNEL_ID = "nexus_overlay_channel";
    private static final int NOTIFICATION_ID = 2042;
    private static final long POLL_INTERVAL_MS = 1200L;
    private static final long LOOKBACK_WINDOW_MS = 10_000L;

    public static boolean running = false;

    private WindowManager windowManager;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private String currentForegroundPackage = null;
    private FilterOverlayView filterView;

    private final Runnable pollTask = new Runnable() {
        @Override
        public void run() {
            pollForegroundApp();
            handler.postDelayed(this, POLL_INTERVAL_MS);
        }
    };

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        startOngoingNotification();
        handler.post(pollTask);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(pollTask);
        hideFilter();
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ---------------------------------------------------------------- foreground notification

    private void startOngoingNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager != null) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "NEXUS автофильтр", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Показывает, что автоопределение игры и фильтр активны");
            manager.createNotificationChannel(channel);
        }

        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent contentIntent = null;
        if (launchIntent != null) {
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
            contentIntent = PendingIntent.getActivity(this, 0, launchIntent, flags);
        }

        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID);
        builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("NEXUS AI GRAPHICS активен")
                .setContentText("Следит за выбранными играми и показывает фильтр поверх них")
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE);
        if (contentIntent != null) builder.setContentIntent(contentIntent);
        Notification notification = builder.build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    // ---------------------------------------------------------------- foreground-app polling

    @SuppressWarnings("deprecation")
    private void pollForegroundApp() {
        String fg = readForegroundPackage();
        if (fg == null || fg.equals(currentForegroundPackage)) return;
        currentForegroundPackage = fg;

        Set<String> targets = prefs.getStringSet("target_packages", Collections.<String>emptySet());
        if (targets.contains(fg)) {
            showOrUpdateFilter(fg);
        } else {
            hideFilter();
        }
    }

    /** Returns the package name of the most recent MOVE_TO_FOREGROUND event in the lookback
     *  window, or null if none happened (which may simply mean nothing changed since the last
     *  poll, OR that Usage access hasn't been granted — both look the same from here). */
    private String readForegroundPackage() {
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            if (usm == null) return null;
            long end = System.currentTimeMillis();
            long begin = end - LOOKBACK_WINDOW_MS;
            UsageEvents events = usm.queryEvents(begin, end);
            String last = null;
            UsageEvents.Event event = new UsageEvents.Event();
            while (events.hasNextEvent()) {
                events.getNextEvent(event);
                if (event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    last = event.getPackageName();
                }
            }
            return last;
        } catch (SecurityException e) {
            return null;
        }
    }

    // ---------------------------------------------------------------- filter overlay window

    private void showOrUpdateFilter(String pkg) {
        float tint = prefs.getFloat("tint_" + pkg, 0.5f);
        float dim = prefs.getFloat("dim_" + pkg, 0f);
        float vignette = prefs.getFloat("vignette_" + pkg, 0f);

        if (filterView == null) {
            FilterOverlayView view = new FilterOverlayView(this);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            p.gravity = Gravity.TOP | Gravity.START;
            try {
                windowManager.addView(view, p);
            } catch (RuntimeException e) {
                return;
            }
            filterView = view;
        }
        filterView.setParams(tint, dim, vignette);
    }

    private void hideFilter() {
        if (filterView == null) return;
        try { windowManager.removeView(filterView); } catch (IllegalArgumentException ignored) { }
        filterView = null;
    }
}

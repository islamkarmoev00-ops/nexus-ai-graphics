package com.nexus.aigraphics;

import android.app.Activity;
import android.app.AppOpsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String PREFS = "nexus_overlay";

    private static final int BG = Color.rgb(8, 14, 26);
    private static final int CARD = Color.rgb(17, 29, 48);
    private static final int CYAN = Color.rgb(62, 211, 255);
    private static final int WHITE = Color.rgb(245, 249, 255);
    private static final int MUTED = Color.rgb(170, 185, 207);

    private TextView status;
    private LinearLayout appListContainer;
    private SharedPreferences prefs;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
        refreshAppList();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(24));
        root.setBackgroundColor(BG);

        TextView eyebrow = text("ANDROID GAMING TOOLKIT  •  v0.4", 11, CYAN, true);
        eyebrow.setGravity(Gravity.CENTER);
        root.addView(eyebrow, new LinearLayout.LayoutParams(-1, dp(28)));

        TextView title = text("NEXUS AI\nGRAPHICS", 31, WHITE, true);
        title.setGravity(Gravity.CENTER);
        title.setLineSpacing(0, 0.95f);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(104)));

        TextView description = text("Выбери игры из списка — для них будет автоматически включаться визуальный фильтр.", 14, MUTED, false);
        description.setGravity(Gravity.CENTER);
        description.setPadding(dp(10), 0, dp(10), dp(16));
        root.addView(description);

        LinearLayout statusCard = card();
        statusCard.addView(text("СОСТОЯНИЕ", 10, CYAN, true));
        status = text("Проверяем разрешения…", 13, WHITE, true);
        status.setPadding(0, dp(6), 0, 0);
        statusCard.addView(status);
        root.addView(statusCard, cardParams());

        Button overlayPermission = button("Разрешение «Поверх других приложений»");
        overlayPermission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                updateStatus();
            }
        });
        root.addView(overlayPermission, buttonParams());

        Button usagePermission = button("Разрешение «Доступ к использованию»");
        usagePermission.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        });
        root.addView(usagePermission, buttonParams());

        Button start = button("Включить автофильтр");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                status.setText("Сначала разреши отображение поверх других приложений.");
                return;
            }
            if (!hasUsageAccess()) {
                status.setText("Сначала разреши «Доступ к использованию» — без него служба не увидит, какая игра открыта.");
                return;
            }
            startForegroundService(new Intent(this, OverlayService.class));
            updateStatus();
        });
        root.addView(start, buttonParams());

        Button stop = button("Остановить службу");
        stop.setTextColor(Color.rgb(255, 164, 164));
        stop.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(67, 35, 48)));
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            updateStatus();
        });
        root.addView(stop, buttonParams());

        LinearLayout listHeader = card();
        listHeader.addView(text("СПИСОК ИГР", 10, CYAN, true));
        TextView listHint = text("Отметь игру галочкой, чтобы фильтр включался для неё автоматически. Нажми на строку, чтобы настроить фильтр для этой игры.",
                11, MUTED, false);
        listHint.setPadding(0, dp(5), 0, 0);
        listHeader.addView(listHint);
        root.addView(listHeader, cardParams());

        appListContainer = new LinearLayout(this);
        appListContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(appListContainer, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout honestCard = card();
        honestCard.addView(text("ВАЖНО О ФИЛЬТРЕ", 10, CYAN, true));
        honestCard.addView(text("Фильтр — это полупрозрачный слой поверх игры: оттенок, затемнение, виньетка. "
                + "Это реально меняет то, что видно на экране, но НЕ делает картинку игры чётче и не убирает "
                + "настоящее размытие — обычное приложение не может читать и пересобирать пиксели чужой игры "
                + "без root. Подробности — в README_RU.md.",
                11, MUTED, false));
        LinearLayout.LayoutParams honestLp = cardParams();
        honestLp.topMargin = dp(8);
        root.addView(honestCard, honestLp);

        scroll.addView(root);
        setContentView(scroll);
        updateStatus();
        refreshAppList();
    }

    // ---------------------------------------------------------------- status + permissions

    @SuppressWarnings("deprecation")
    private boolean hasUsageAccess() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
        if (appOps == null) return false;
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private void updateStatus() {
        if (status == null) return;
        boolean overlayAllowed = Settings.canDrawOverlays(this);
        boolean usageAllowed = hasUsageAccess();
        String line1 = overlayAllowed ? "Оверлей: разрешён" : "Оверлей: НЕ разрешён";
        String line2 = usageAllowed ? "Доступ к использованию: разрешён" : "Доступ к использованию: НЕ разрешён";
        String line3 = OverlayService.running ? "Служба: активна" : "Служба: остановлена";
        status.setText(line1 + "\n" + line2 + "\n" + line3);
    }

    // ---------------------------------------------------------------- app list

    private void refreshAppList() {
        if (appListContainer == null) return;
        appListContainer.removeAllViews();

        PackageManager pm = getPackageManager();
        Intent launcherIntent = new Intent(Intent.ACTION_MAIN, null);
        launcherIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(launcherIntent, 0);

        List<ResolveInfo> sorted = new ArrayList<>(apps);
        Collections.sort(sorted, (a, b) -> {
            String labelA = a.loadLabel(pm).toString();
            String labelB = b.loadLabel(pm).toString();
            return labelA.compareToIgnoreCase(labelB);
        });

        Set<String> targets = prefs.getStringSet("target_packages", Collections.<String>emptySet());
        String self = getPackageName();

        for (ResolveInfo info : sorted) {
            String pkg = info.activityInfo.packageName;
            if (pkg.equals(self)) continue;
            String label = info.loadLabel(pm).toString();
            Drawable icon;
            try { icon = info.loadIcon(pm); } catch (Exception e) { icon = null; }
            addAppRow(pkg, label, icon, targets.contains(pkg));
        }
    }

    private void addAppRow(String pkg, String label, Drawable icon, boolean checked) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(9), dp(8), dp(9));
        row.setBackground(rowBackground());

        ImageView iconView = new ImageView(this);
        if (icon != null) iconView.setImageDrawable(icon);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(34), dp(34));
        iconLp.rightMargin = dp(11);
        row.addView(iconView, iconLp);

        TextView labelView = text(label, 13, WHITE, false);
        labelView.setMaxLines(1);
        row.addView(labelView, new LinearLayout.LayoutParams(0, -2, 1));

        CheckBox checkBox = new CheckBox(this);
        checkBox.setChecked(checked);
        checkBox.setButtonTintList(ColorStateList.valueOf(CYAN));
        row.addView(checkBox, new LinearLayout.LayoutParams(dp(40), dp(40)));
        checkBox.setOnClickListener(v -> setTarget(pkg, checkBox.isChecked()));

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
        rowLp.bottomMargin = dp(2);
        appListContainer.addView(row, rowLp);

        labelView.setOnClickListener(v -> openProfile(pkg));
        iconView.setOnClickListener(v -> openProfile(pkg));
    }

    private void setTarget(String pkg, boolean include) {
        Set<String> current = new HashSet<>(prefs.getStringSet("target_packages", Collections.<String>emptySet()));
        if (include) current.add(pkg); else current.remove(pkg);
        prefs.edit().putStringSet("target_packages", current).apply();
    }

    private void openProfile(String pkg) {
        Intent i = new Intent(this, ProfileActivity.class);
        i.putExtra("package_name", pkg);
        startActivity(i);
    }

    private GradientDrawable rowBackground() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(CARD);
        d.setCornerRadius(dp(10));
        return d;
    }

    // ---------------------------------------------------------------- small view builders

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(15));
        bg.setStroke(dp(1), Color.rgb(40, 61, 83));
        c.setBackground(bg);
        return c;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(12);
        return p;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinHeight(dp(54));
        b.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(17, 76, 105)));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56));
        p.bottomMargin = dp(9);
        return p;
    }
}

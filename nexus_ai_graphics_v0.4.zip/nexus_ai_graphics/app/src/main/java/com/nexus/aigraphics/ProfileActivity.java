package com.nexus.aigraphics;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Per-app profile editor for the decorative filter (tint / dim / vignette). Includes a live
 * preview so it's obvious this is a translucent layer effect, not real image processing.
 */
public class ProfileActivity extends Activity {
    private static final String PREFS = "nexus_overlay";

    private static final int BG = Color.rgb(9, 16, 30);
    private static final int CARD = Color.rgb(17, 29, 48);
    private static final int CYAN = Color.rgb(62, 211, 255);
    private static final int MUTED = Color.rgb(166, 181, 203);
    private static final int WHITE = Color.rgb(245, 249, 255);

    private String packageName;
    private SharedPreferences prefs;
    private FilterOverlayView preview;

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        packageName = getIntent().getStringExtra("package_name");
        if (packageName == null) { finish(); return; }
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = vertical();
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = label(appLabel(), 20, WHITE, true);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(40)));
        TextView pkg = label(packageName, 11, MUTED, false);
        root.addView(pkg, new LinearLayout.LayoutParams(-1, dp(24)));

        LinearLayout disclaimer = card();
        disclaimer.addView(label("ЧТО ЭТО НА САМОМ ДЕЛЕ", 10, CYAN, true));
        TextView note = label("Это декоративный полупрозрачный слой поверх игры (оттенок, затемнение, "
                + "виньетка по краям) — он реально меняет то, что вы видите на экране, точно как "
                + "фильтры «ночного режима». Он НЕ делает картинку игры чётче и не убирает реальное "
                + "размытие — для этого нужен доступ к пикселям самой игры, которого у обычного "
                + "приложения нет.", 11, WHITE, false);
        note.setPadding(0, dp(6), 0, 0);
        disclaimer.addView(note);
        root.addView(disclaimer, cardParams());

        FrameLayout previewBox = new FrameLayout(this);
        previewBox.setBackground(previewBackdrop());
        preview = new FilterOverlayView(this);
        previewBox.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, dp(150));
        previewLp.topMargin = dp(4);
        previewLp.bottomMargin = dp(14);
        root.addView(previewBox, previewLp);

        float tint = prefs.getFloat("tint_" + packageName, 0.5f);
        float dim = prefs.getFloat("dim_" + packageName, 0f);
        float vignette = prefs.getFloat("vignette_" + packageName, 0f);
        preview.setParams(tint, dim, vignette);

        SeekBar tintBar = addSlider(root, "Оттенок: прохладный ↔ тёплый", Math.round(tint * 100));
        SeekBar dimBar = addSlider(root, "Затемнение", Math.round(dim * 100));
        SeekBar vignetteBar = addSlider(root, "Виньетка по краям", Math.round(vignette * 100));

        SeekBar.OnSeekBarChangeListener liveUpdate = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                preview.setParams(tintBar.getProgress() / 100f, dimBar.getProgress() / 100f, vignetteBar.getProgress() / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        };
        tintBar.setOnSeekBarChangeListener(liveUpdate);
        dimBar.setOnSeekBarChangeListener(liveUpdate);
        vignetteBar.setOnSeekBarChangeListener(liveUpdate);

        LinearLayout buttons = horizontal();
        Button reset = new Button(this);
        reset.setText("Сбросить");
        reset.setTextColor(MUTED);
        reset.setBackground(shape(CARD, Color.rgb(43, 69, 91), 12));
        LinearLayout.LayoutParams resetLp = new LinearLayout.LayoutParams(0, dp(48), 1);
        resetLp.rightMargin = dp(8);
        buttons.addView(reset, resetLp);
        reset.setOnClickListener(v -> {
            tintBar.setProgress(50);
            dimBar.setProgress(0);
            vignetteBar.setProgress(0);
            preview.setParams(0.5f, 0f, 0f);
        });

        Button save = new Button(this);
        save.setText("Сохранить");
        save.setTextColor(WHITE);
        save.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        save.setBackground(shape(Color.rgb(13, 55, 79), Color.rgb(36, 126, 159), 12));
        buttons.addView(save, new LinearLayout.LayoutParams(0, dp(48), 1));
        save.setOnClickListener(v -> {
            prefs.edit()
                    .putFloat("tint_" + packageName, tintBar.getProgress() / 100f)
                    .putFloat("dim_" + packageName, dimBar.getProgress() / 100f)
                    .putFloat("vignette_" + packageName, vignetteBar.getProgress() / 100f)
                    .apply();
            finish();
        });

        LinearLayout.LayoutParams buttonsLp = new LinearLayout.LayoutParams(-1, -2);
        buttonsLp.topMargin = dp(16);
        root.addView(buttons, buttonsLp);
    }

    private String appLabel() {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo info = pm.getApplicationInfo(packageName, 0);
            return pm.getApplicationLabel(info).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return packageName;
        }
    }

    private GradientDrawable previewBackdrop() {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(70, 90, 60), Color.rgb(40, 60, 90), Color.rgb(90, 70, 40)});
        d.setCornerRadius(dp(13));
        return d;
    }

    private SeekBar addSlider(LinearLayout parent, String title, int progress) {
        LinearLayout item = card();
        item.addView(label(title, 12, WHITE, true));
        SeekBar seek = new SeekBar(this);
        seek.setMax(100);
        seek.setProgress(progress);
        seek.setProgressTintList(ColorStateList.valueOf(CYAN));
        seek.setThumbTintList(ColorStateList.valueOf(WHITE));
        seek.setProgressBackgroundTintList(ColorStateList.valueOf(Color.rgb(48, 65, 86)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(35));
        lp.topMargin = dp(4);
        item.addView(seek, lp);
        parent.addView(item, cardParams());
        return seek;
    }

    // ---------------------------------------------------------------- small view builders

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout card() {
        LinearLayout c = vertical();
        c.setPadding(dp(11), dp(10), dp(11), dp(9));
        c.setBackground(shape(CARD, Color.rgb(39, 60, 82), 13));
        return c;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(9);
        return p;
    }
}

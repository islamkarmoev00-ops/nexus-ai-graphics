package com.nexus.aigraphics;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/**
 * Purely decorative overlay effect.
 *
 * This view has no access to the pixels of the app underneath it — it only draws its own
 * translucent layer ON TOP of whatever is on screen. That means:
 *  - Dimming (a semi-transparent black layer) is real: it genuinely darkens the screen,
 *    the same trick used by "blue light / night mode" screen-filter apps.
 *  - Tint (a semi-transparent warm/cool color layer) is real: it genuinely shifts the color
 *    cast of the screen.
 *  - Vignette (a radial gradient, darker at the edges) is real: it genuinely darkens the
 *    screen edges.
 *  - There is NO sharpness or de-blur control here, on purpose: making a game's actual image
 *    sharper or less blurry requires reading and transforming the pixels that are already on
 *    screen, which a normal overlay window cannot do. Layering something on top cannot
 *    manufacture detail that was never captured — so this view does not pretend to offer that.
 */
public class FilterOverlayView extends View {
    private float tint = 0.5f;      // 0 = cool/blue, 0.5 = neutral (no tint), 1 = warm/orange
    private float dim = 0f;         // 0 = off, 1 = strongest dimming
    private float vignette = 0f;    // 0 = off, 1 = strongest edge darkening

    private final Paint paint = new Paint();

    public FilterOverlayView(Context context) {
        super(context);
        setWillNotDraw(false);
    }

    public void setParams(float tint, float dim, float vignette) {
        this.tint = tint;
        this.dim = dim;
        this.vignette = vignette;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        if (dim > 0.01f) {
            paint.setShader(null);
            paint.setColor(Color.argb((int) (dim * 140), 0, 0, 0));
            canvas.drawRect(0, 0, w, h, paint);
        }

        float tintStrength = Math.abs(tint - 0.5f) * 2f;
        if (tintStrength > 0.01f) {
            int base = tint > 0.5f ? Color.rgb(255, 150, 60) : Color.rgb(60, 150, 255);
            paint.setShader(null);
            paint.setColor(Color.argb((int) (tintStrength * 70),
                    Color.red(base), Color.green(base), Color.blue(base)));
            canvas.drawRect(0, 0, w, h, paint);
        }

        if (vignette > 0.01f) {
            float radius = Math.max(w, h) * 0.75f;
            RadialGradient gradient = new RadialGradient(
                    w / 2f, h / 2f, radius,
                    Color.argb(0, 0, 0, 0),
                    Color.argb((int) (vignette * 200), 0, 0, 0),
                    Shader.TileMode.CLAMP);
            paint.setShader(gradient);
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
        }
    }
}
